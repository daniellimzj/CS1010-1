/********************************************************
 * CS1010 AY2017/8 Semester 1
 * PE1 Ex2: teetoo.c
 * Name: 
 * Student number: 
 * plab-id: 
 * Discussion group: 
 * Description: 
 *
 ********************************************************/

#include <stdio.h>

int main(void) {
	long long num;

	printf("Enter a positive integer: ");
	scanf("%lli", &num);
	printf("%lli\n", num);


	return 0;
}

