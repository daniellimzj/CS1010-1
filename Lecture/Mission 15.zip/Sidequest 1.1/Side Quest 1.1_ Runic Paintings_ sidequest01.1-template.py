#
# CS1010S --- Programming Methodology
#
# Mission 1 - Side Quest
#
# Note that written answers are commented out to allow us to run your
# code easily while grading your problem set.

from runes import *

##########
# Task 1 #
##########

def egyptian(params):
    # Fill in code here
    return

# Test
show(egyptian(make_cross(rcross_bb), 5))
