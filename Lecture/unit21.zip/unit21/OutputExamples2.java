// Demonstrating a few System.out methods.
import java.text.*;

public class OutputExamples2 {

	public static void main(String[] args) {
		DecimalFormat df1 = new DecimalFormat("000.00");
		DecimalFormat df2 = new DecimalFormat("###.##");
		DecimalFormat df3 = new DecimalFormat("0.0%");
		DecimalFormat df4 = new DecimalFormat("0,000");
		DecimalFormat df5 = new DecimalFormat("#,###");

		double y = 2.37609, z = 36.9;
		int a = 1234567, b = 89;

		System.out.println("y = " + df1.format(y) + "; z = " + df1.format(z));
		System.out.println("y = " + df2.format(y) + "; z = " + df2.format(z));
		System.out.println("y = " + df3.format(y) + "; z = " + df3.format(z));
		System.out.println("a = " + df4.format(a) + "; b = " + df4.format(b));
		System.out.println("a = " + df5.format(a) + "; b = " + df5.format(b));
	}
}

