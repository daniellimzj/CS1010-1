// Demonstrating a few System.out methods.

public class OutputExamples1 {

	public static void main(String[] args) {

		int a = 123, b = 456;
		double x = 78.9;
		String str = "Hello world!";

		System.out.print("a = " + a);
		System.out.println("; b = " + b);
		System.out.print("x = " + x + " and ");
		System.out.println("str = " + str);

		System.out.printf("a = %d; b = %d\n", a, b);
		System.out.printf("x = %f and ", x);
		System.out.printf("str = %s\n", str);
	}
}

