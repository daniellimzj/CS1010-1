// The program computes the area of a circle.
import java.util.*;
import java.text.*;

public class AreaOfCircle {

	public static void main(String[] args) {
		DecimalFormat df = new DecimalFormat("#.###");
		Scanner sc = new Scanner(System.in);
		double radius, area;

		System.out.print("Enter radius: ");
		radius = sc.nextDouble();
		area = Math.PI * Math.pow(radius, 2);

		System.out.println("Area = " + df.format(area));
	}
}

