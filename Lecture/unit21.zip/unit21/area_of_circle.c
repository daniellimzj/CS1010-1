// The program computes the area of a circle.
#include <stdio.h>
#include <math.h>
#define PI 3.14159

int main(void) {
	double radius, area;

	printf("Enter radius: ");
	scanf("%lf", &radius);
	area = PI * pow(radius, 2);
	printf("Area = %.3f\n", area);

	return 0;
}

