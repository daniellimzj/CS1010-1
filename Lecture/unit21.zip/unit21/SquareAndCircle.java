// This program computes the area of circle inscribing a square.
import java.util.*;
import java.text.*;

public class SquareAndCircle {

	public static void main(String[] args) {
		DecimalFormat df = new DecimalFormat("#.###");
		Scanner sc = new Scanner(System.in);
		double length; // length of the square
		double area;   // area of the circle

		System.out.print("Enter length of square: ");
		length = sc.nextDouble();
		area = computeArea(length);

		System.out.println("Area of circle = " + df.format(area));
	}

	public static double computeArea(double length) {
		return Math.PI * (length * length)/2;
	}
}

