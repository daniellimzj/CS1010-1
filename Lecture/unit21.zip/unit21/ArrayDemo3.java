// Demonstrate use of array in Java
import java.util.*;

public class ArrayDemo3 {

	public static void main(String[] args) {
		int[] arr = new int[3];
		scanArray(arr);
		System.out.println("Sum = " + sumArray(arr));
	}

	public static void scanArray(int[] a) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter " + a.length + " values: ");
		for (int i=0; i<a.length; i++) {
			a[i] = sc.nextInt();
		}
	}

	public static int sumArray(int[] a) {
		int sum = 0;
		for (int i=0; i<a.length; i++) {
			sum += a[i];
		}
		return sum;
	}
}

