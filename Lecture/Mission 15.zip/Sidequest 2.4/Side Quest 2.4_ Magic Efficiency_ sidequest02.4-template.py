#
# CS1010S --- Programming Methodology
#
# Mission 2 - Side Quest 2
#
# Note that written answers are commented out to allow us to run your
# code easily while grading your problem set.

##########
# Task 1 #
##########

# Simplifed Order notations:

# 4^n * n^2
# Ans:

# n * 3^n
# Ans:

# 1000000000n^2
# Ans:

# 2^n/1000000000
# Ans:

# n^n + n^2 + 1
# Ans:

# 4^n + 2^n
# Ans:

# 1^n
# Ans:

# n^2
# Ans:

# Faster order of growth in each group:

# i.
# ii.
# iii.
# iv.


##########
# Task 2 #
##########

# Time complexity: 
# Space complexity: 


##########
# Task 3 #
##########

# Time complexity of bar:
# Time complexity of foo:

# Space complexity of bar:
# Space complexity of foo:

def improved_foo(params):
    # Fill in code here
    return

# Improved time complexity:
# Improved space complexity:
