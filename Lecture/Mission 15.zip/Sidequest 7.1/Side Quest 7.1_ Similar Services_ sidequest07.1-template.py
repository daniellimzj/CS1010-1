#
# CS1010S --- Programming Methodology
#
# Sidequest 7.1 Template
#
# Note that written answers are commented out to allow us to run your
# code easily while grading your problem set.

from buses import *

##############
# Additional #
##############

smrt_routes = read_route_data('smrt_routes.txt')
service_106_data = filter_routes(smrt_routes, "106")
service_106 = make_service(service_106_data, "106")

service_171_data = filter_routes(smrt_routes, "171")
service_171 = make_service(service_171_data, "171")

all_bus_stops = read_bus_stop_data('bus_stops_full.txt')

##########
# Task 1 #
##########

def find_similarity(route, service, stops):
    service_routes = get_routes(service)
    all_similar_roads = ()
    route_roads = get_roads(route, stops)

    for a_route in service_routes:
        other_roads = get_roads(a_route, stops)
        similar_roads = find_similar_roads(route_roads, other_roads)
        all_similar_roads += (similar_roads,)

    return all_similar_roads

#############
# Task 1(a) #
#############

def get_routes(service):
    """Your solution below"""


# service_106_routes = get_routes(service_106)

# print_tuple(service_106_routes)

# Expected Output #

# Note that the order may be slightly different due to the implementation of make_service used. It will be marked correct so long as the routes contained are the same.

# (('43009', '43179', '43189', '43619', '43629', '42319', '28109', '28189', '28019', '20109', '17189', '17179', '17169', '17159', '19049', '19039', '19029', '19019', '11199', '11189', '11401', '11239', '11229', '11219', '11209', '13029', '13019', '09149', '09159', '09169', '09179', '09048', '09038', '08138', '08057', '08069', '04179', '02049', 'E0200', '02151', '02161', '02171', '03509', '03519', '03539', '03129', '03218', '03219'), ('03239', '03211', 'E0321', 'E0564', '03222',
# 'E0599', '03531', '03511', '03501', '02051', '02061', '04111', '04121', '08041', '08031', '08111', '08121', '09059', '09022', '09111', '09121', '09131', '09141', '13011', '13021', '11201', '11211', '11221', '11231', '11419', '11409', '11181', '11191', '19011', '19021', '19031', '19041', '17151', '17161', '17171', '17181', '20101', '28011', '28181', '28101', '42311', '43621', '43611', '43181', '43171', '43009'))
# OR
# (('03239', '03211', 'E0321', 'E0564', '03222', 'E0599', '03531', '03511', '03501', '02051', '02061', '04111', '04121', '08041', '08031', '08111', '08121', '09059', '09022', '09111', '09121', '09131', '09141', '13011', '13021', '11201', '11211', '11221', '11231', '11419', '11409', '11181', '11191', '19011', '19021', '19031', '19041', '17151', '17161', '17171', '17181', '20101', '28011', '28181', '28101', '42311', '43621', '43611', '43181', '43171', '43009'), ('43009', '43179',
# '43189', '43619', '43629', '42319', '28109', '28189', '28019', '20109', '17189', '17179', '17169', '17159', '19049', '19039', '19029', '19019', '11199', '11189', '11401', '11239', '11229', '11219', '11209', '13029', '13019', '09149', '09159', '09169', '09179', '09048', '09038', '08138', '08057', '08069', '04179', '02049', 'E0200', '02151', '02161', '02171', '03509', '03519', '03539', '03129', '03218', '03219'))


#############
# Task 1(b) #
#############

def get_roads(route, stops):
    """Your solution below"""


# first_106_route = get_route(service_106, "1")
# first_106_route_roads = get_roads(first_106_route, all_bus_stops)

# print_tuple(first_106_route_roads)

# Expected Output #

# Your answer may not be in the same order as below. You may wish to use the 'in' operator to check that all the roads in your answer are in the answer below. Note that there should be no duplicate roads.

# ('Bt Batok Ctrl', 'Bt Batok East Ave 3', 'Toh Tuck Ave', "C'wealth Ave West", "C'wealth Ave", 'Holland Ave', 'Holland Rd', 'Napier Rd', 'Tanglin Rd', 'Orchard Rd', 'Bras Basah Rd', 'Raffles Blvd', 'Temasek Blvd', 'Temasek Ave', 'Bayfront Ave', 'Central Blvd', 'Shenton Way', 'Palmer Rd')

#############
# Task 1(c) #
#############

def find_similar_roads(first_roads, second_roads):
    """Your solution below"""


# all_similar_roads = find_similarity(first_106_route, service_171, all_bus_stops)
# print_tuple(all_similar_roads)

# Expected Output #

# Your answers may not be in the same order as below but should have the same values.

# (('Orchard Rd', 'Bras Basah Rd', 'Raffles Blvd'), ('Orchard Rd', 'Raffles Blvd'))
# OR
# (('Orchard Rd', 'Raffles Blvd'), ('Orchard Rd', 'Bras Basah Rd', 'Raffles Blvd'))
