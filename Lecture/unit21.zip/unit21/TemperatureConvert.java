// To convert Fahrenheit to Celsius degree.
import java.util.*;

public class TemperatureConvert {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		float fah, cel;  // degrees Fahrenheit and Celsius

		System.out.print("Enter temperature in Fahrenheit: ");
		fah = sc.nextFloat();

		cel = (fah - 32) * 5/9;
		System.out.println("Temperature in Celsius = " + cel);
	}
}

