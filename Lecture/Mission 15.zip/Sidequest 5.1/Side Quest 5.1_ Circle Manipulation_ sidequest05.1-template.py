#
# CS1010S --- Programming Methodology
#
# Mission 5 - Sidequest 1
#
# Note that written answers are commented out to allow us to run your
# code easily while grading your problem set.

from hi_graph import *

##########
# Task 1 #
##########

# your answer here

##########
# Task 2 #
##########

# (a)
def spiral(t):
    "your answer here"

# draw_connected_scaled(1000, spiral)

# (b)
def heart(t):
    "your answer here"

# draw_connected_scaled(1000, heart)
