// To convert Fahrenheit to Celsius degree.
#include <stdio.h>

int main(void) {
	float fah, cel; // degrees Fahrenheit and Celsius

	printf("Enter temperature in Fahrenheit: ");
	scanf("%f", &fah);

	cel = (fah - 32) * 5/9;
	printf("Temperature in Celsius = %f\n", cel);

	return 0;
}

