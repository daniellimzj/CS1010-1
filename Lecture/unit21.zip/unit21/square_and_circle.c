// This program computes the area of circle inscribing a square.
#include <stdio.h>
#define PI 3.14159

double compute_area(double);

int main(void) {
	double length; // length of the square
	double area;   // area of the circle

	printf("Enter length of square: ");
	scanf("%lf", &length);
	area = compute_area(length);
	printf("Area of circle = %.3f\n", area);

	return 0;
}

double compute_area(double length) {
	return PI * (length * length)/2;
}

