#
# CS1010S --- Programming Methodology
#
# Mission 7 Template
#
# Note that written answers are commented out to allow us to run your
# code easily while grading your problem set.

import pprint

## Pre-defined ##

def map(fn, seq):
    res = ()

    for ele in seq:
        res = res + (fn(ele), )
    return res

def filter(pred, seq):
    res = ()

    for ele in seq:
        if pred(ele):
            res = res + (ele, )
    return res

def make_bus_stop(code, road_name, description):
    return (code, road_name, description)

def get_code(bus_stop):
    return bus_stop[0]

def get_road_name(bus_stop):
    return bus_stop[1]

def get_description(bus_stop):
    return bus_stop[2]

def read_bus_stop_data(filename):
    stops = ()
    with open(filename, 'r') as f:
        for line in f:
            line = line[:-1] # removing the newline character
            code, road_name, description = line.split(',')
            bus_stop = make_bus_stop(code, road_name, description)
            stops = stops + (bus_stop, )
    return stops

def lookup_bus_stop_by_code(stops, code):
    for bus_stop in stops:
        if get_code(bus_stop) == code:
            return bus_stop
    return None

def lookup_bus_stop_by_road(stops, road):
    matched = ()
    for bus_stop in stops:
        if get_road_name(bus_stop) == road:
            matched = matched + (bus_stop, )
    return matched

def print_tuple(tup):
    pprint.PrettyPrinter(indent=2).pprint(tup)

bus_stops = read_bus_stop_data('bus_stops.txt')

##########
# Task 1 #
##########

def read_route_data(filename):
    with open(filename, 'r') as f:
        lines = tuple(f)
        """Your solution here"""


print("## Q1 ##")
# bus_stations = read_route_data('smrt_routes.txt')
# print_tuple(bus_stations[:5]) # printing just the first 5 as it gets too long otherwise

# Expected Output #
# ( ('106', '1', '1', '43009'),
#   ('106', '1', '2', '43179'),
#   ('106', '1', '3', '43189'),
#   ('106', '1', '4', '43619'),
#   ('106', '1', '5', '43629'))

##########
# Task 2 #
##########

def lookup_bus_stop_by_road(stops, road):
    """Your solution here"""


print("## Q2 ##")
# matching_stops = lookup_bus_stop_by_road(bus_stops, 'Victoria St')
# print_tuple(matching_stops)

# Expected Output #
# ( ('01012', 'Victoria St', 'Hotel Grand Pacific'),
#   ('01013', 'Victoria St', "St. Joseph's Ch"),
#   ('01019', 'Victoria St', 'Bras Basah Cplx'),
#   ('01059', 'Victoria St', 'Bugis Stn'),
#   ('01112', 'Victoria St', 'Opp Bugis Junction'),
#   ('01113', 'Victoria St', 'Bugis Stn'))


##########
# Task 3 #
##########

def filter_routes(routes_data, service_code):
    data = filter(lambda entry: entry[0] == service_code, routes_data)
    return data

def make_service(service_data, service_code):
    routes = ()
    curr_route = ()

    first_station = service_data[0]
    curr_dir = first_station[1]

    for entry in service_data:
        direction = entry[1]
        stop = entry[3]

        if direction == curr_dir:
            curr_route = curr_route + (stop, )
        else:
            routes = routes + (curr_route, )
            curr_route = (stop, )
            curr_dir = direction

    routes = routes + (curr_route, )
    return (service_code, routes)

################
# Task 3(a)(i) #
################

def get_service_code(service):
    """Your solution below"""


print("## Q3(a)(i) ##")
# service_106_data = filter_routes(bus_stations, "106")
# service_106 = make_service(service_106_data, "106")
# print(get_service_code(service_106))

# Expected Output #

# 106

#################
# Task 3(a)(ii) #
#################

def get_route(service, direction):
    """Your solution below"""


print("## Q3(a)(ii) ##")
# print_tuple(get_route(service_106, '1'))

# Expected Output #

# ('43009', '43179', '43189', '43619', '43629', '42319', '28109', '28189', '28019', '20109', '17189', '17179', '17169', '17159', '19049', '19039', '19029', '19019', '11199', '11189', '11401', '11239', '11229', '11219', '11209', '13029', '13019', '09149', '09159', '09169', '09179', '09048', '09038', '08138', '08057', '08069', '04179', '02049', 'E0200', '02151', '02161', '02171', '03509', '03519', '03539', '03129', '03218', '03219')

################
# Task 3(b)(i) #
################

def make_service(service_data, service_code):
    """Modify the code below"""
    routes = ()
    curr_route = ()

    first = service_data[0]
    curr_dir = first[1]

    # addition no.1

    for entry in service_data:
        direction = entry[1]
        stop = entry[3]

        if direction == curr_dir:
            curr_route = curr_route + (stop, )
        else:
            routes = routes + (curr_route, )
            curr_route = (stop, )
            curr_dir = direction
            # addition no.2

    routes = routes + (curr_route, )

    # modification no.3
    return (service_code, routes)

print("## Q3(b)(i) ##")
# service_106 = make_service(service_106_data, "106")
# print(get_service_code(service_106))

# Expected Output #

# 106

#################
# Task 3(b)(ii) #
#################

def get_directions(service):
    """Your solution below"""


print("## Q3(b)(ii) ##")
# print_tuple(get_directions(service_106))

# Expected Output #

# ('1', '2')

##################
# Task 3(b)(iii) #
##################

def get_route(service, direction):
    """Your solution below"""


print("## Q3(b)(iii) ##")
# print_tuple(get_route(service_106, '2'))

# Expected Output #

# ('03239', '03211', 'E0321', 'E0564', '03222', 'E0599', '03531', '03511', '03501', '02051', '02061', '04111', '04121', '08041', '08031', '08111', '08121', '09059', '09022', '09111', '09121', '09131', '09141', '13011', '13021', '11201', '11211', '11221', '11231', '11419', '11409', '11181', '11191', '19011', '19021', '19031', '19041', '17151', '17161', '17171', '17181', '20101', '28011', '28181', '28101', '42311', '43621', '43611', '43181', '43171', '43009')

#############
# Task 4(a) #
#############

def split_routes(routes_data):
    """Your solution below"""


print("## Q4(a) ##")
# grouped_routes = split_routes(bus_stations)
# service_171_data = filter(lambda pair: pair[0] == "171", grouped_routes)[0]
# print(service_171_data[0])
# print_tuple(service_171_data[1][:5]) # first 5 elements only
# service_171 = make_service(service_171_data[1], service_171_data[0])

# Expected Output #

# 171
# ( ('171', '1', '1', '59009'),
#   ('171', '1', '2', '59141'),
#   ('171', '1', '3', '59111'),
#   ('171', '1', '4', '57089'),
#   ('171', '1', '5', '57079'))

#############
# Task 4(b) #
#############

def make_services(routes_data):
    """Your solution below"""


print("## Q4(b) ##")
# smrt_services = make_services(bus_stations)
# print_tuple(smrt_services)
# service_184 = filter(lambda service: get_service_code(service) == '184', smrt_services)[0]

# Expected Output #
# ( ( '106',
#     ('1', '2'),
#     ( ( '43009',
#         '43179',
#         '43189',
#         '43619',
#         '43629',
#         '42319',
#         '28109',
#         '28189',
#         '28019',
#         '20109',
#         '17189',
#         '17179',
#         '17169',
#         '17159',
#         '19049',
#         '19039',
#         '19029',
#         '19019',
#         '11199',
#         '11189',
#         '11401',
#         '11239',
#         '11229',
#         '11219',
#         '11209',
#         '13029',
#         '13019',
#         '09149',
#         '09159',
#         '09169',
#         '09179',
#         '09048',
#         '09038',
#         '08138',
#         '08057',
#         '08069',
#         '04179',
#         '02049',
#         'E0200',
#         '02151',
#         '02161',
#         '02171',
#         '03509',
#         '03519',
#         '03539',
#         '03129',
#         '03218',
#         '03219'),
#       ( '03239',
#         '03211',
#         'E0321',
#         'E0564',
#         '03222',
#         'E0599',
#         '03531',
#         '03511',
#         '03501',
#         '02051',
#         '02061',
#         '04111',
#         '04121',
#         '08041',
#         '08031',
#         '08111',
#         '08121',
#         '09059',
#         '09022',
#         '09111',
#         '09121',
#         '09131',
#         '09141',
#         '13011',
#         '13021',
#         '11201',
#         '11211',
#         '11221',
#         '11231',
#         '11419',
#         '11409',
#         '11181',
#         '11191',
#         '19011',
#         '19021',
#         '19031',
#         '19041',
#         '17151',
#         '17161',
#         '17171',
#         '17181',
#         '20101',
#         '28011',
#         '28181',
#         '28101',
#         '42311',
#         '43621',
#         '43611',
#         '43181',
#         '43171',
#         '43009'))),
#   ( '171',
#     ('1', '2'),
#     ( ( '59009',
#         '59141',
#         '59111',
#         '57089',
#         '57079',
#         '57069',
#         '57059',
#         '48149',
#         '48069',
#         '48059',
#         '48049',
#         '48039',
#         '48029',
#         '48019',
#         'BKE',
#         '44269',
#         '44229',
#         '44219',
#         '44209',
#         '44631',
#         '44259',
#         '44029',
#         '44019',
#         '43119',
#         '43109',
#         '43089',
#         '43069',
#         '43059',
#         '43049',
#         '43029',
#         '43019',
#         '42119',
#         '42109',
#         '42089',
#         '42059',
#         '42049',
#         '42039',
#         '42029',
#         '42019',
#         '41089',
#         '41079',
#         '41069',
#         '41049',
#         '41029',
#         '41019',
#         '40099',
#         '40089',
#         '40079',
#         '40119',
#         '40069',
#         '40059',
#         '40049',
#         '40189',
#         '40179',
#         '09219',
#         '09047',
#         '09037',
#         '08138',
#         '08057',
#         '08069',
#         '04179',
#         '02049',
#         '02089'),
#       ( '02099',
#         '02101',
#         '02051',
#         '02061',
#         '04111',
#         '04121',
#         '08041',
#         '08031',
#         '08111',
#         '08121',
#         'E0902',
#         'E0901',
#         '09011',
#         '09023',
#         '09212',
#         '40171',
#         '40181',
#         '40041',
#         '40051',
#         '40111',
#         '40071',
#         '40081',
#         '40091',
#         '41011',
#         '41021',
#         '41031',
#         '41041',
#         '41051',
#         '41061',
#         '41071',
#         '41081',
#         '42011',
#         '42021',
#         '42031',
#         '42041',
#         '42051',
#         '42061',
#         '42071',
#         '42091',
#         '42111',
#         '43011',
#         '43021',
#         '43041',
#         '43051',
#         '43061',
#         '43071',
#         '43081',
#         '43091',
#         '43111',
#         '44011',
#         '44021',
#         '44251',
#         '44639',
#         '44201',
#         '44211',
#         '44221',
#         '44261',
#         'BKE',
#         '48011',
#         '48021',
#         '48031',
#         '48041',
#         '48051',
#         '48061',
#         '48141',
#         '57051',
#         '57061',
#         '57071',
#         '57081',
#         '59119',
#         '59149',
#         '59072',
#         '59009'))),
#   ( '184',
#     ('1',),
#     ( ( '45009',
#         'E4501',
#         '44241',
#         '44231',
#         '44229',
#         '43139',
#         '43129',
#         '43109',
#         '43089',
#         '43069',
#         '43059',
#         '43049',
#         '43029',
#         '43019',
#         '42119',
#         '42109',
#         '42089',
#         '42149',
#         '12109',
#         '12099',
#         '12089',
#         '12079',
#         '12069',
#         '17229',
#         '17179',
#         '17169',
#         '17241',
#         '17111',
#         '12061',
#         '12071',
#         '12081',
#         '12091',
#         '12101',
#         '42141',
#         '42071',
#         '42091',
#         '42111',
#         '43011',
#         '43021',
#         '43041',
#         '43051',
#         '43061',
#         '43071',
#         '43081',
#         '43091',
#         '43121',
#         '43131',
#         '44221',
#         '44239',
#         '44249',
#         'E4501',
#         '45009'),)))

##########
# Task 5 #
##########

def connecting_services(road1, road2, services, stops):
    results = ()

    for service in services:
        if connects(road1, road2, service, stops):
            results = results + (get_service_code(service), )

    return results

def connects(road1, road2, service, stops):
    service_code = get_service_code(service)
    direction_tuple = get_directions(service)

    routes = map(lambda direction: get_route(service, direction), direction_tuple)

    for route in routes:
        if route_connects(road1, road2, route, stops):
            return True
    return False

def route_connects(road1, road2, route, stops):
    """Your solution below"""


print("## Q5 ##")
# stops = read_bus_stop_data('bus_stops_full.txt')
# connecting_svcs = connecting_services("Orchard Rd", "Bras Basah Rd", smrt_services, stops)
# service_106_1 = get_route(service_106, "1")
# service_171_1 = get_route(service_171, "1")
# service_184_1 = get_route(service_184, "1")
# print(route_connects("Orchard Rd", "Bras Basah Rd", service_106_1, stops))
# print(route_connects("Orchard Rd", "Bras Basah Rd", service_171_1, stops))
# print(route_connects("Orchard Rd", "Bras Basah Rd", service_184_1, stops))
# print_tuple(connecting_svcs)

# Expected Output #

# True
# True
# False
# ('106', '171')
