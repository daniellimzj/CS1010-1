// Demonstrating a few Scanner methods.
import java.util.*;

public class InputExamples {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int a = sc.nextInt();
		double b = sc.nextDouble();
		String str1 = sc.next();
		String str2 = sc.nextLine();

		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("str1 = " + str1);
		System.out.println("str2 = " + str2);
	}
}

