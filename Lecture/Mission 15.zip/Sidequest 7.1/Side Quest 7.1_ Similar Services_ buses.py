import pprint

_map = map
_filter = filter

def map(fn, seq):
    return tuple(_map(fn, seq))

def filter(pred, seq):
    return tuple(_filter(pred, seq))

def filter_routes(routes_data, service_code):
    data = filter(lambda entry: entry[0] == service_code,
     routes_data)
    return data

def read_route_data(filename):
    with open(filename, 'r') as f:
        lines = tuple(f)
        return map(lambda line: tuple((line[:-1]).split(',')), lines)

def make_bus_stop(code, road_name, description):
    return (code, road_name, description)

def get_code(bus_stop):
    return bus_stop[0]

def get_road_name(bus_stop):
    return bus_stop[1]

def get_description(bus_stop):
    return bus_stop[2]

def read_bus_stop_data(filename):
    stops = []
    with open(filename, 'r') as f:
        for line in f:
            line = line[:-1] # removing the newline character
            code, road_name, description = line.split(',')
            bus_stop = make_bus_stop(code, road_name, description)
            stops.append(bus_stop)
    return stops

def lookup_bus_stop_by_code(stops, code):
    res = filter(lambda stop: code == get_code(stop), stops)
    return res[0] if res else res

def lookup_bus_stop_by_road(stops, road):
    return filter(lambda stop: get_road_name(stop) == road, stops)

def make_service(service_data, service_code):
    routes = []

    directions = tuple(set(map(lambda entry: entry[1], service_data)))

    for direction in directions:
        one_direction = filter(lambda entry: entry[1] == direction, service_data)
        route = map(lambda thing: thing[3], one_direction)

        routes.append(route)

    return lambda t: service_code if t == 0 else (directions if t == 1 else routes)

def get_service_code(service):
    return service(0)

def get_directions(service):
    return service(1)

def get_route(service, direction):
    directions = get_directions(service)
    routes = service(2)

    res = filter(lambda pair: pair[0] == direction, zip(directions, routes))

    return res[0][1] if res else res

def print_tuple(tup):
    pprint.PrettyPrinter(indent=2).pprint(tup)


