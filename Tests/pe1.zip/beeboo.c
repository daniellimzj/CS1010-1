/********************************************************
 * CS1010 AY2017/8 Semester 1
 * PE1 Ex1: beeboo.c
 * Name: 
 * Student number: 
 * plab-id: 
 * Discussion group: 
 * Description: 
 *
 ********************************************************/

#include <stdio.h>

int main(void) {
	int num;

	printf("Enter a positive integer: ");
	scanf("%d", &num);
	printf("%d\n", num);


	return 0;
}

