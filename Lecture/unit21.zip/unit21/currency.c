// To convert S$ to Malaysian Ringgit.
#include <stdio.h>
#define SGD_TO_MYR 3.0269

int main(void) {
	double sing_dollar, ringgit;

	printf("Enter currency: S$");
	scanf("%lf", &sing_dollar);

	ringgit = SGD_TO_MYR * sing_dollar;
	printf("That's %.2f ringgit.\n", ringgit);

	return 0;
}

