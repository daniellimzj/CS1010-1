// Assigning grade according to marks
import java.util.*;

public class Grade {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter marks (0-100): ");
		int marks = sc.nextInt();
		char grade;

		switch (marks/10) {
			case 8: case 9: case 10: grade = 'A'; break;
			case 7: grade = 'B'; break;
			case 6: grade = 'C'; break;
			case 5: grade = 'D'; break;
			default: grade = 'F'; 
		}
		System.out.println("Grade = " + grade);
	}
}

