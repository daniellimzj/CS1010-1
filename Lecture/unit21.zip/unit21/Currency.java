// To convert S$ to Malaysian Ringgit
import java.util.*;
import java.text.*;

public class Currency {
	private static final double SGD_TO_MYR = 3.0269;

	public static void main(String[] args) {
		DecimalFormat df = new DecimalFormat("0.00");
		Scanner sc = new Scanner(System.in);
		double singDollar, ringgit; 

		System.out.print("Enter currency: S$");
		singDollar = sc.nextDouble();

		ringgit = SGD_TO_MYR * singDollar;
		System.out.println("That's " + df.format(ringgit) + " ringgit.");
	}
}

